export class User{
    id: number= 0;
    firstName: String = '';
    lastName: String = '';
    email: String = '';
    password: String ='';
    loginAs: String = '';
}
