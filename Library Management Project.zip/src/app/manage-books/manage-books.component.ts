import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-books',
  templateUrl: './manage-books.component.html',
  styleUrls: ['./manage-books.component.css']
})
export class ManageBooksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
